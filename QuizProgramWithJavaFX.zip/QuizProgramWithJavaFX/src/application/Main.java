package application;
	


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.*;


import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.TabPane.TabClosingPolicy;
import javafx.scene.control.TextArea;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.scene.image.*;



public class Main extends Application {
	
	private static DataSource ds = new DataSource();
	public BorderPane bPane = new BorderPane();
	public Text currentText = new Text();
	
	public boolean quizReady = false;
	public boolean textMessage = false;
	public List<QuestionsList> qList = new ArrayList<QuestionsList>();
	public List<AnswersList> AnsList = new ArrayList<AnswersList>();
	public Text text = new Text();
	public int correctAnswer;
	public int questionCount = 0;
	public double score;
	public static String inputValue = "";
	public static int index = 0;
	public static boolean answered = false;
	public static boolean alreadySet = false;
	public static RadioButton rb = null;
	public static TextArea textArea = null;
	public static String quizQA = "";
	
	@Override
	public void start(Stage primaryStage) {
		
			TabPane tabPane = new TabPane();
			tabPane.setTabClosingPolicy(TabClosingPolicy.UNAVAILABLE);
			
			
			Tab tab1 = new Tab("Take Quiz");
			Tab tab2 = new Tab("Quiz Setting");
			
			
			
			tabPane.getTabs().addAll(tab1,tab2);
			tabPane.setStyle("-fx-background-color:  #3b2e5a");
			
			AnchorPane anchor = new AnchorPane();
			AnchorPane.setTopAnchor(tabPane, 15.0);
		    AnchorPane.setRightAnchor(tabPane, 15.0);
		    AnchorPane.setBottomAnchor(tabPane, 15.0);
		    AnchorPane.setLeftAnchor(tabPane, 15.0);
			
			anchor.getChildren().addAll(tabPane);
			anchor.setStyle("-fx-background-color:  #a2de96");
			Scene scene = new Scene(anchor,800,500);
			
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			
			primaryStage.setTitle("Welcome to Quiz Program");
			primaryStage.setScene(scene);
			primaryStage.show();
			
			//Setting Tab 2 details
			
			BorderPane bPaneTab2 = new BorderPane();		
			
			VBox vbox = new VBox();
			vbox.setSpacing(20);
			vbox.setAlignment(Pos.CENTER);
			
			String[] topicList = {"Select Topic","GK"};
			
			String[] levels = {"Select Level","Easy","Hard"};
			
			ComboBox<String> topic = new ComboBox<String>(FXCollections.observableArrayList(topicList));
			topic.setValue("Select Topic");
			
			ComboBox<String> level = new ComboBox<String>(FXCollections.observableArrayList(levels));
			level.setValue("Select Level");
			
			Button generate = new Button("Generate Quiz");
			generate.setId("menuButton");
			
			
			Button getPdf = new Button("Export Quiz");
			getPdf.setId("menuButton");
			
			FileChooser fileChooser = new FileChooser();
			fileChooser.setTitle("Save");
			fileChooser.getExtensionFilters().addAll(new ExtensionFilter("All Files", "*.*"));
			
			
			
			
			
			generate.setOnAction(new EventHandler<ActionEvent>() {
				
				
				@Override
				public void handle(ActionEvent arg0) {
					
					quizReady = checkQuizOptions(topic,level);
					
					if(textMessage)
					{
						text.setText("");
						bPaneTab2.getChildren().remove(text);
						textMessage = false;
					}
					
					if(quizReady) 
							
					{
						qList.removeAll(qList);
						AnsList.removeAll(AnsList);
						
						qList = ds.generateQuestion(topic.getValue(),level.getValue(),qList);
						
						try {
							AnsList = ds.generateAnswer(qList);
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}								
						
						quizQA = createQuizTxt(topic.getValue(),level.getValue());
						text.setText("Quiz generated !");
						text.setFont(Font.font("Verdana", FontWeight.EXTRA_BOLD, 18));
						text.setStroke(Color.YELLOWGREEN);
						BorderPane.setAlignment(text, Pos.CENTER);
						BorderPane.setMargin(text, new Insets(12,12,12,12)); // optional
						bPaneTab2.setBottom(text);
						textMessage = true;
											
					}
					
					else {						
						
						text.setText("Select all options and then click Generate Quiz !");
						text.setFont(Font.font("Verdana", FontWeight.EXTRA_BOLD, 15));
						text.setStroke(Color.WHITE);
						BorderPane.setAlignment(text, Pos.CENTER);
						BorderPane.setMargin(text, new Insets(12,12,12,12)); // optional
						bPaneTab2.setBottom(text);					
						textMessage = true;
					}
					
					
				}

				private String createQuizTxt(String topic, String level) {

				    quizQA = "\t\tQuiz\n\tTopic :"+topic+"\t\tLevel :"+level;
			        
			        for(int i =0;i<qList.size();i++)
			        {
			        	QuestionsList q = qList.get(i);
			        	int index = 0;
			        	
			        	for(AnswersList a: AnsList)
						{
							if(a.getQid().equals(q.getQid()))
							{
								index = AnsList.indexOf(a);
								break;
							}
						}        	
			        	
			        	quizQA+= "\n\n"+(i+1);			        	    	
			        	
			        	if(q.getqType().equals("MCQ"))
			        	{
			        		quizQA +=". "+q.getQuestion();
			        		int count = 1;			        		
			        		quizQA += "\n\t"+count+". "+AnsList.get(index).getAns1();
			        		quizQA += "\n\t"+(++count)+". "+AnsList.get(index).getAns2();
			        		quizQA += "\n\t"+(++count)+". "+AnsList.get(index).getAns3();
			        		quizQA += "\n\t"+(++count)+". "+AnsList.get(index).getAns4();
			        		quizQA += "\n\t"+" Correct Answer : "+AnsList.get(index).getAnswer();
			        	}
			        	
			        	else {
			        		
			        		quizQA +=". Image location -> "+q.getQuestion();
			        		quizQA += "\n\t "+AnsList.get(index).getAns1();
			        		quizQA += "\n\t"+" Correct Answer : "+AnsList.get(index).getAnswer();
			        		
			        		
			        	}
			        	
			        }
					
					
					return quizQA;
					
					
					
				}

				private boolean checkQuizOptions(ComboBox<String> topic, ComboBox<String> level) {

					if(topic.getValue().equals("Select Topic") || level.getValue().equals("Select Level"))
					return false;
					
					else
						return true;
				}
				
				
				
			});
			
			
			getPdf.setOnAction(new EventHandler<ActionEvent>() {
				
				@Override
				public void handle(ActionEvent event) {

						if(quizReady)
						{
							File file = new File("Quiz.txt");
							
							BufferedWriter fw = null;
							
							try {
								
								fw = new BufferedWriter(new FileWriter(file));
								
								fw.write(quizQA);
								
								fw.close();
							}catch(IOException e)
							{
								e.printStackTrace();
							}
							
							text.setText("File generated and saved as Quiz.txt");
							text.setFont(Font.font("Verdana", FontWeight.EXTRA_BOLD, 15));
							text.setStroke(Color.ORANGE);
							
						}
						
						else {
							
							text.setText("No data to Generate PDF...");
							text.setFont(Font.font("Verdana", FontWeight.EXTRA_BOLD, 15));
							text.setStroke(Color.DARKOLIVEGREEN);
							
							
						}
					
					
						
						BorderPane.setAlignment(text, Pos.CENTER);
						BorderPane.setMargin(text, new Insets(12,12,12,12)); // optional
						bPaneTab2.setBottom(text);					
						textMessage = true;
						
						
					
					
					
				}
				
				
			});
			
			vbox.getChildren().addAll(topic,level,generate,getPdf);
			
			bPaneTab2.setCenter(vbox);
			
			tab2.setContent(bPaneTab2);
			
			
			//Setting Tab 1 contents
			
			//Main Opening Label
			
			Label mainLabel = new Label("Welcome to Quiz !");
			mainLabel.setWrapText(true);
			mainLabel.setFont(Font.font("Verdana", FontWeight.BOLD, 40));
			mainLabel.setTextAlignment(TextAlignment.CENTER);
			mainLabel.setTextFill(Color.BLUEVIOLET);
			
			Button start = new Button("Start the Quiz");
			start.setId("fancyButton");
			
			
			BorderPane.setAlignment(start, Pos.CENTER);
			BorderPane.setMargin(start, new Insets(12,12,12,12)); // optional
			bPane.setBottom(start);
			bPane.setCenter(mainLabel);
			
			tab1.setContent(bPane);
			bPane.setStyle("-fx-background-color:  #fff48f");
			
			//Start Button Action
			
			start.setOnAction(new EventHandler<ActionEvent>() {
				
				@Override
				public void handle(ActionEvent event) {
					
					if(quizReady)
					{
						bPane.getChildren().remove(start);
						
						runQuiz(qList.get(questionCount),AnsList);
						
						if(answered)
						{
							BorderPane.setAlignment(start, Pos.CENTER);
							BorderPane.setMargin(start, new Insets(12,12,12,12)); // optional
							bPane.setBottom(start);
						}
						
						
					}
					
					
					else {
						
						currentText.setText("Please generate the Quiz first !");
						currentText.setId("fancytext");
						bPane.setCenter(currentText);
						
					}
					
					
					
				}

				private void runQuiz(QuestionsList q, List<AnswersList> ansList) 
				{
						
						VBox vbox = new VBox();
						vbox.setAlignment(Pos.CENTER);
						vbox.setSpacing(10);
						for(AnswersList a: ansList)
						{
							if(a.getQid().equals(q.getQid()))
							{
								index = ansList.indexOf(a);
								break;
							}
						}

						Button submit = new Button("Submit");
						submit.setFont(Font.font("Calibri", FontWeight.BOLD, 17));
						submit.setPrefSize(100, 30);
						submit.setStyle(" -fx-base: #ffffff;");
						submit.setTextFill(Color.BLUEVIOLET);
						submit.setDisable(true);
						BorderPane.setAlignment(submit, Pos.CENTER);
						BorderPane.setMargin(submit, new Insets(12,12,12,12)); // optional
						bPane.setBottom(submit);
						
							if(q.getqType().equals("MCQ"))
							{
								Label Ques = new Label(q.getQuestion());
								Ques.setId("question");
								
								RadioButton rb1 = new RadioButton(ansList.get(index).getAns1());
								rb1.setFont(Font.font("Times New Roman", FontWeight.BOLD, 18));
								RadioButton rb2 = new RadioButton(ansList.get(index).getAns2());
								rb2.setFont(Font.font("Times New Roman", FontWeight.BOLD, 18));
								RadioButton rb3 = new RadioButton(ansList.get(index).getAns3());
								rb3.setFont(Font.font("Times New Roman", FontWeight.BOLD, 18));
								RadioButton rb4 = new RadioButton(ansList.get(index).getAns4());
								rb4.setFont(Font.font("Times New Roman", FontWeight.BOLD, 18));
								
								
								//To ensure only 1 is selected
								
								ToggleGroup radio = new ToggleGroup();
								rb1.setToggleGroup(radio);
								rb2.setToggleGroup(radio);
								rb3.setToggleGroup(radio);
								rb4.setToggleGroup(radio);

								vbox.getChildren().addAll(Ques,rb1,rb2,rb3,rb4);
								
								bPane.setCenter(vbox);
								
								
								
								
								radio.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {

									@Override
									public void changed(ObservableValue<? extends Toggle> a, Toggle b, Toggle c) {

										rb = (RadioButton)radio.getSelectedToggle();
										
										if(rb!=null)
										{
											submit.setDisable(false);
																				
										}
										
									}

									
								});						
								
								
							}
							
							else if(q.getqType().equals("Open"))
							{
								Label Ques = new Label(ansList.get(index).getAns1());
								Ques.setId("question");
								
								String url = q.getQuestion(); 
								FileInputStream fs= null;
								
								try {
									fs = new FileInputStream(url);
								} catch (FileNotFoundException e) {
									// TODO Auto-generated catch block
									System.out.println("File not found !");
								}
								
								Image image = new Image(fs);
								
								HBox hb = new HBox();
								Label textLabel = new Label("Enter your answer here ");
								textLabel.setId("question");
								textArea = new TextArea();
								textArea.setPrefWidth(300);
								textArea.setPrefHeight(5);
								textArea.setFont(Font.font("Times New Roman", FontWeight.MEDIUM, 15));
								hb.setAlignment(Pos.CENTER);
								hb.getChildren().addAll(textLabel,textArea);
								
								javafx.scene.image.ImageView img = new javafx.scene.image.ImageView(image);
								img.setFitHeight(300);
								img.setFitWidth(300);
								
								vbox.getChildren().addAll(Ques,img,hb);
								
								bPane.setCenter(vbox);
								
								textArea.textProperty().addListener(new ChangeListener<String>() {

									@Override
									public void changed(ObservableValue<? extends String> arg0, String arg1, String t1) {

										submit.setDisable(false);
										
									}
								});
								
							}
							
							submit.setOnAction(new EventHandler<ActionEvent>() {

								@Override
								public void handle(ActionEvent arg0) {
									
									if(q.getqType().contentEquals("MCQ"))
									{
										inputValue = rb.getText();
									}
									else {
										inputValue =  textArea.getText();
									}
									
									if(inputValue.equalsIgnoreCase(ansList.get(index).getAnswer()))
									{
										correctAnswer++;									
										
												
									}
									if(questionCount<=4)
									{
										questionCount++;
										runQuiz(qList.get(questionCount),AnsList);
									}
									else {
										bPane.getChildren().removeAll(vbox,submit);
										
										displayResult(submit);
										
									}
									
									
																
								}
								
								
							});
							
						
						
								
				}

				private void displayResult(Button submit) {
					
					Label label = new Label();
					
					
					
					System.out.println("Correct Answers -> "+correctAnswer);
					double score = ((double)correctAnswer/(double)(questionCount+1))*100;

					DecimalFormat df = new DecimalFormat("#.##");
					
					String result = "\n\t\tQuiz Result"
								  + "\n\t\t***********\n\n"+
							"\tCorrect Answers : "+correctAnswer+
						  "\n\tScore		    : "+df.format(score)+"%";
					
					label.setText(result);
					label.setFont(Font.font("Verdana", FontWeight.BOLD, 30));
					label.setTextFill(Color.RED);
					bPane.setCenter(label);					
					
					Button reStart = new Button("Exit");
					reStart.setFont(Font.font("Calibri", FontWeight.BOLD, 17));
					reStart.setPrefSize(100, 30);
					reStart.setStyle(" -fx-base: #ffffff;");
					reStart.setTextFill(Color.BLUEVIOLET);
					BorderPane.setAlignment(reStart, Pos.CENTER);
					BorderPane.setMargin(reStart, new Insets(12,12,12,12)); // optional
					bPane.setBottom(reStart);
				
					
					reStart.setOnAction(new EventHandler<ActionEvent>() {
						
						@Override
						public void handle(ActionEvent arg0) {
							ds.close();
							System.exit(0);
							
						}
					});
					
									
				}

			
			});
			
			
			
	}
	
	public static void main(String[] args) {
		
		//Create & Load Database
		
		createAndLoadDatabase();
		
		launch(args);
		
		ds.close();
	}

	private static void createAndLoadDatabase() {
				
		if(ds.open())
		{
			System.out.println("Database successfully opened !");
		}
		else {
			System.out.println("Could not open Database !");
		}
		
		//Dropping tables if already created & creating new tables
		
		ds.createAndDropTables();
		
		//Adding data to tables from text file
		
		ds.loadTables();
		

	}


		
	}


