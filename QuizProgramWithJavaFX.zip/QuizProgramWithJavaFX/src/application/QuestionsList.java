package application;

public class QuestionsList {

	private String Qid;
	private String topic;
	private String level;
	private String qType;
	private String question;
	
	public QuestionsList(String qid, String topic, String level, String qType, String question)
	{
		this.Qid = qid;
		this.topic = topic;
		this.level = level;
		this.qType = qType;
		this.question = question;
	}
	
	public String getQid() {
		return Qid;
	}
	public String getTopic() {
		return topic;
	}
	public String getLevel() {
		return level;
	}
	public String getqType() {
		return qType;
	}
	public String getQuestion() {
		return question;
	}

	@Override
	public String toString() {
		return "QuestionsList [Qid=" + Qid + ", topic=" + topic + ", level=" + level + ", qType=" + qType
				+ ", question=" + question + "]";
	}
	
	
	
	
	
}
