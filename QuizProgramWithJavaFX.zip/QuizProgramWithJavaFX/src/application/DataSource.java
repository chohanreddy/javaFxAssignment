package application;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class DataSource {
	
	public static final String DB = "QuizDataDB.db";
	
	public static final String CONNECTION_STRING = "jdbc:sqlite:src//application//"+DB;
	
	//Data Variable
	
	public static final String TABLE_QUESTION = "Questions";
	public static final String TABLE_ANSWER = "Answers";
	
	
	private Connection conn;
	
	private Statement statement = null;
	
	
    public boolean open() {
        try {
            conn = DriverManager.getConnection(CONNECTION_STRING);
            return true;
        } catch(SQLException e) {
            System.out.println("Couldn't connect to database: " + e.getMessage());
            return false;
        }
    }

    public void close() {
        try {
            if(conn != null) {
                conn.close();
                System.out.println("Database successfully closed !");
            }
        } catch(SQLException e) {
            System.out.println("Couldn't close connection: " + e.getMessage());
        }
    }
	
	
	public void createAndDropTables()
	{
		
		try {
			statement = conn.createStatement();
			statement.execute("DROP TABLE IF EXISTS " +TABLE_QUESTION);
			statement.execute("DROP TABLE IF EXISTS " +TABLE_ANSWER);
			
			System.out.println("Tables dropped");
			
			statement.execute("CREATE TABLE IF NOT EXISTS " +TABLE_QUESTION+
					"(Qid PRIMARY KEY,TOPIC TEXT NOT NULL,LEVEL TEXT NOT NULL,"
					+ "QuestionType TEXT NOT NULL,Question TEXT NOT NULL)");
			
			statement.execute("CREATE TABLE IF NOT EXISTS " +TABLE_ANSWER+
					"(Qid PRIMARY KEY,Ans1 TEXT,Ans2 TEXT,Ans3 TEXT,"
					+ "Ans4 TEXT,Answer TEXT)");
			
			System.out.println("Tables created");
			//statement.close();
				
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	public void loadTables()
	{
		Scanner scan = null;
		//Reading from text file and filling up the table
		try {
			statement = conn.createStatement();
			scan = new Scanner(new BufferedReader(new FileReader(new File("src\\application\\QuizData"))));
			
			while(scan.hasNextLine())
			{
				String str = scan.nextLine();
				String[] val = str.split(",");
				
			
				statement.execute("INSERT INTO "+TABLE_QUESTION+
						" (Qid,TOPIC,LEVEL,QuestionType,Question)"+
						" VALUES('"+val[0]+"','"+val[1]+"','"+val[2]+
								"','"+val[3]+"','"+val[4]+"')");
				
				if(val[3].equals("MCQ"))
				{
					statement.execute("INSERT INTO "+TABLE_ANSWER+
							" (Qid,Ans1,Ans2,Ans3,Ans4,Answer)"+
							" VALUES('"+val[0]+"','"+val[5]+"','"+val[6]+"'"
									+ ",'"+val[7]+"','"+val[8]+"','"+val[9]+"')");         
				}
				else if(val[3].equals("Open")) {
					statement.execute("INSERT INTO "+TABLE_ANSWER+
							"(Qid,Ans1,Answer)"+
							"VALUES('"+val[0]+"','"+val[5]+"','"+val[6]+"')");					
					
				}
				
			}
			
			scan.close();
			statement.close();
			
			System.out.println("Table loaded...");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

	//Generating Questions
	public List<QuestionsList> generateQuestion(String topic, String level, List<QuestionsList> qAList) {

		
		ResultSet result = null;
		Statement statement1 = null;
		
		String l1 = "",l2="";
		
		try {
			statement1 = conn.createStatement();
			
			if(level.equals("Easy"))
			{
				l1 = "Easy";
				l2 = "Medium";
			}
			else {
				l1 = "Medium";
				l2 = "Hard";
			}
			
			String query = "SELECT * FROM Questions WHERE LEVEL = '"+l1+"' UNION "
					+ "SELECT * FROM Questions WHERE LEVEL = '"+l2+"' LIMIT 6";
			result = statement1.executeQuery(query);
		
		
		
		while(result.next())
		{
			
			QuestionsList qA = new QuestionsList(result.getString(1),
					result.getString(2), result.getString(3),
					result.getString(4), result.getString(5));
						
			qAList.add(qA);
			
			
		}

		System.out.println("Questions were pulled !");	
		
		
		} catch (SQLException e) {
			
			
			e.printStackTrace();
		}finally {
			try {
				statement1.close();
			
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
			
		
		return qAList;
	}

	public List<AnswersList> generateAnswer(List<QuestionsList> qList) throws SQLException {
		
		List<AnswersList> AnsList = new ArrayList<AnswersList>();
		ResultSet result1 = null;
		Statement statement2 = conn.createStatement();
		
		for(QuestionsList q : qList)
		{
			String query1 = "SELECT * FROM Answers WHERE QID = '"+q.getQid()+"'";
			result1 = statement2.executeQuery(query1);
			
			AnswersList a = new AnswersList(q.getQid(), result1.getString(2),
					result1.getString(3),result1.getString(4),result1.getString(5)
					,result1.getString(6));
			
			AnsList.add(a);
		}

		
		System.out.println("Answers were pulled !");	
	
		return AnsList;
	}	
	

}
