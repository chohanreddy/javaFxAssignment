package application;


public class AnswersList {
	
	private String Qid;
	private String ans1;
	private String ans2;
	private String ans3;
	private String ans4;
	private String answer;
	
	public AnswersList(String qid,String ans1, String ans2, String ans3, String ans4, String answer) {
		this.Qid = qid;
		this.ans1 = ans1;
		this.ans2 = ans2;
		this.ans3 = ans3;
		this.ans4 = ans4;
		this.answer = answer;
	}

	public String getQid() {
		return Qid;
	}

	public String getAns1() {
		return ans1;
	}

	public String getAns2() {
		return ans2;
	}

	public String getAns3() {
		return ans3;
	}

	public String getAns4() {
		return ans4;
	}

	public String getAnswer() {
		return answer;
	}

	@Override
	public String toString() {
		return "AnswersList [Qid=" + Qid + ", ans1=" + ans1 + ", ans2=" + ans2 + ", ans3=" + ans3 + ", ans4=" + ans4
				+ ", answer=" + answer + "]";
	}
	
	
	

}
